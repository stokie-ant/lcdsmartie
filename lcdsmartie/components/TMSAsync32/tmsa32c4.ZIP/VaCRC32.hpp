// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaCrc32.pas' rev: 4.00

#ifndef VaCrc32HPP
#define VaCrc32HPP

#pragma delphiheader begin
#pragma option push -w-
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vacrc32
{
//-- type declarations -------------------------------------------------------
typedef unsigned dwLongint;

#pragma pack(push, 4)
struct TCRC16
{
	
	union
	{
		struct 
		{
			Word Value;
			
		};
		struct 
		{
			Byte Bytes[2];
			
		};
		
	};
} ;
#pragma pack(pop)

#pragma pack(push, 4)
struct TCRC32
{
	
	union
	{
		struct 
		{
			unsigned Value;
			
		};
		struct 
		{
			Byte Bytes[4];
			
		};
		
	};
} ;
#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
static const Shortint InitCRC16 = 0x0;
static const unsigned InitCRC32 = 0xffffffff;
extern PACKAGE unsigned __fastcall CalcCRC32(Byte Value, unsigned CRC);
extern PACKAGE Word __fastcall CalcCRC16(Byte Value, Word CRC);

}	/* namespace Vacrc32 */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vacrc32;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaCrc32
