// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaObjects.pas' rev: 4.00

#ifndef VaObjectsHPP
#define VaObjectsHPP

#pragma delphiheader begin
#pragma option push -w-
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vaobjects
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TVaHandleObject;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaHandleObject : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	unsigned FHandle;
	int FError;
	
public:
	__fastcall virtual ~TVaHandleObject(void);
	__property unsigned Handle = {read=FHandle, nodefault};
	__property int Error = {read=FError, nodefault};
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TVaHandleObject(void) : System::TObject() { }
	#pragma option pop
	
};

#pragma pack(pop)

#pragma option push -b-
enum TVaEventWaitResult { wrSignaled, wrTimeout, wrAbandoned, wrError };
#pragma option pop

class DELPHICLASS TVaEvent;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaEvent : public TVaHandleObject 
{
	typedef TVaHandleObject inherited;
	
public:
	__fastcall TVaEvent(Windows::PSecurityAttributes EventAttributes, bool ManualReset, bool InitialState
		, const AnsiString Name);
	TVaEventWaitResult __fastcall WaitFor(unsigned Timeout);
	void __fastcall SetEvent(void);
	void __fastcall ResetEvent(void);
public:
	#pragma option push -w-inl
	/* TVaHandleObject.Destroy */ inline __fastcall virtual ~TVaEvent(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TVaWaitEvent;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaWaitEvent : public TVaEvent 
{
	typedef TVaEvent inherited;
	
public:
	__fastcall TVaWaitEvent(void);
public:
	#pragma option push -w-inl
	/* TVaHandleObject.Destroy */ inline __fastcall virtual ~TVaWaitEvent(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TVaCriticalSection;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaCriticalSection : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	_RTL_CRITICAL_SECTION FSection;
	
public:
	__fastcall TVaCriticalSection(void);
	__fastcall virtual ~TVaCriticalSection(void);
	void __fastcall Acquire(void);
	void __fastcall Release(void);
	void __fastcall Enter(void);
	void __fastcall Leave(void);
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vaobjects */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vaobjects;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaObjects
