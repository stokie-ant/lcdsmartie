//---------------------------------------------------------------------------

#ifndef UtaDemoH
#define UtaDemoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "VaClasses.hpp"
#include "VaComm.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TStatusBar *StatusBar1;
        TPanel *Panel1;
        TEdit *EditTransmit;
        TCheckBox *CheckBoxAddLinefeed;
        TButton *ButtonTransmit;
        TButton *Button1;
        TCheckBox *CheckBoxRTS;
        TCheckBox *CheckBoxDTR;
        TCheckBox *CheckBoxBREAK;
        TCheckBox *CheckBoxXON;
        TPanel *Panel2;
        TSplitter *Splitter1;
        TPanel *Panel3;
        TMemo *Memo2;
        TPanel *Panel4;
        TMemo *Memo1;
        TPanel *Panel5;
        TButton *ButtonOpen;
        TButton *ButtonClose;
        TButton *ButtonReset;
        TPanel *Panel6;
        TLabel *LabelParity;
        TLabel *LabelStopbits;
        TLabel *LabelDataBits;
        TLabel *LabelBaudrate;
        TBevel *Bevel1;
        TBevel *Bevel2;
        TLabel *Label1;
        TComboBox *ComboParity;
        TComboBox *ComboStopbits;
        TComboBox *ComboDatabits;
        TComboBox *ComboBaudrate;
        TComboBox *ComboPortNum;
        TButton *Button2;
        TVaComm *VaComm1;
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall ButtonOpenClick(TObject *Sender);
        void __fastcall VaComm1Break(TObject *Sender);
        void __fastcall VaComm1Close(TObject *Sender);
        void __fastcall VaComm1Cts(TObject *Sender);
        void __fastcall VaComm1Dsr(TObject *Sender);
        void __fastcall VaComm1Error(TObject *Sender, int Errors);
        void __fastcall VaComm1Event1(TObject *Sender);
        void __fastcall VaComm1Event2(TObject *Sender);
        void __fastcall VaComm1Open(TObject *Sender);
        void __fastcall VaComm1PErr(TObject *Sender);
        void __fastcall VaComm1Ring(TObject *Sender);
        void __fastcall VaComm1Rlsd(TObject *Sender);
        void __fastcall VaComm1Rx80Full(TObject *Sender);
        void __fastcall VaComm1RxChar(TObject *Sender, int Count);
        void __fastcall VaComm1RxFlag(TObject *Sender);
        void __fastcall VaComm1TxEmpty(TObject *Sender);
        void __fastcall ButtonCloseClick(TObject *Sender);
        void __fastcall ButtonResetClick(TObject *Sender);
        void __fastcall ButtonTransmitClick(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall ComboPortNumChange(TObject *Sender);
        void __fastcall ComboBaudrateChange(TObject *Sender);
        void __fastcall ComboDatabitsChange(TObject *Sender);
        void __fastcall ComboStopbitsChange(TObject *Sender);
        void __fastcall ComboParityChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
