//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UtaDemo.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "VaClasses"
#pragma link "VaComm"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
  VaComm1->ResetPortParameters();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
//  Application.OnException := HandleException;


  ComboPortNum->ItemIndex = ComboPortNum->Items->IndexOf("3");
  ComboBaudrate->ItemIndex = ComboBaudrate->Items->IndexOf("br38400");

  ComboDatabits->ItemIndex = ComboDatabits->Items->IndexOf("db8");
  ComboParity->ItemIndex = ComboParity->Items->IndexOf("paNone");
  ComboStopbits->ItemIndex = ComboStopbits->Items->IndexOf("sb10");

  //Make sure we skip the brUser flag in TVaBaudRate
  VaComm1->Baudrate = TVaBaudrate(ComboBaudrate->ItemIndex+1);
  VaComm1->Databits = TVaDatabits(ComboDatabits->ItemIndex);
  VaComm1->Parity = TVaParity(ComboParity->ItemIndex);
  VaComm1->Stopbits = TVaStopbits(ComboStopbits->ItemIndex);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonOpenClick(TObject *Sender)
{
  VaComm1->Open();
  VaComm1Cts(VaComm1);
  VaComm1Dsr(VaComm1);
  VaComm1Ring(VaComm1);
  VaComm1Rlsd(VaComm1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Break(TObject *Sender)
{
  Memo1->Lines->Add("Break signal detected...");        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Close(TObject *Sender)
{
  Memo1->Lines->Add("Port closed");        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Cts(TObject *Sender)
{
  if (VaComm1->CTS)
    StatusBar1->Panels->Items[0]->Text = "CTS";
  else StatusBar1->Panels->Items[0]->Text = "";

}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Dsr(TObject *Sender)
{
  if (VaComm1->DSR)
    StatusBar1->Panels->Items[1]->Text = "DSR";
  else StatusBar1->Panels->Items[1]->Text = "";

}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Error(TObject *Sender, int Errors)
{
  if (Errors & CE_BREAK > 0)  Memo1->Lines->Add(sCE_BREAK);
  if (Errors & CE_DNS > 0)  Memo1->Lines->Add(sCE_DNS);
  if (Errors & CE_FRAME > 0)  Memo1->Lines->Add(sCE_FRAME);
  if (Errors & CE_IOE > 0)  Memo1->Lines->Add(sCE_IOE);
  if (Errors & CE_MODE > 0)  Memo1->Lines->Add(sCE_MODE);
  if (Errors & CE_OOP > 0)  Memo1->Lines->Add(sCE_OOP);
  if (Errors & CE_OVERRUN > 0)  Memo1->Lines->Add(sCE_OVERRUN);
  if (Errors & CE_PTO > 0)  Memo1->Lines->Add(sCE_PTO);
  if (Errors & CE_RXOVER > 0)  Memo1->Lines->Add(sCE_RXOVER);
  if (Errors && CE_RXPARITY > 0)  Memo1->Lines->Add(sCE_RXPARITY);
  if (Errors && CE_TXFULL > 0)  Memo1->Lines->Add(sCE_TXFULL);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Event1(TObject *Sender)
{
  Memo1->Lines->Add("Provider specific event 1.");        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Event2(TObject *Sender)
{
  Memo1->Lines->Add("Provider specific event 2.");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Open(TObject *Sender)
{
  Memo1->Lines->Add("Port open");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1PErr(TObject *Sender)
{
  Memo1->Lines->Add("Printer error detected.");        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Ring(TObject *Sender)
{

//  if (VaComm1->Ring) then
//    StatusBar1->Panels->Items[2]->Text = "RING";
//  else StatusBar1->Panels->Items[2]->Text = "";

}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Rlsd(TObject *Sender)
{
//  if (VaComm1->Rlsd)
//    StatusBar1->Panels->Items[3]->Text = "RLSD";
//  else StatusBar1->Panels->Items[3]->Text = "";

}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1Rx80Full(TObject *Sender)
{
  Memo1->Lines->Add("Receiver buffer is 80% full.");        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1RxChar(TObject *Sender, int Count)
{
  Memo2->Lines->Text = Memo2->Lines->Text + VaComm1->ReadText();
  Memo1->Lines->Add("Reading " + IntToStr(Count) + " bytes");

}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1RxFlag(TObject *Sender)
{
  Memo1->Lines->Add("RxFlag character received.");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VaComm1TxEmpty(TObject *Sender)
{
  Memo1->Lines->Add("TxEmpty signal detected...");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonCloseClick(TObject *Sender)
{
  VaComm1->Close();
  VaComm1Cts(VaComm1);
  VaComm1Dsr(VaComm1);
  VaComm1Ring(VaComm1);
  VaComm1Rlsd(VaComm1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonResetClick(TObject *Sender)
{
  Memo1->Lines->Clear();
  Memo2->Lines->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonTransmitClick(TObject *Sender)
{
  AnsiString S;
  Boolean Ok;
  int i;

  S = EditTransmit->Text;
  if (CheckBoxAddLinefeed->Checked)
    S = S + "\r\n";
  Ok = VaComm1->WriteText(S);

  i = S.Length();

  if (!Ok)
    Memo1->Lines->Add("Error writing to: " + Format("Port %d", ARRAYOFCONST(((int)VaComm1->PortNum))));
  else Memo1->Lines->Add(Format("Writing %d characters", ARRAYOFCONST(((int)i))));

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
  AnsiString S;
  int i;

  if (MessageDlg("This will sent the input a thousand times, continue?",
    mtConfirmation, TMsgDlgButtons() << mbOK << mbCancel, 0) == mrOk)
  {

  S = EditTransmit->Text;
  if (CheckBoxAddLinefeed->Checked)
    S = S + "\r\n";
  for (i = 1; i < 1000;i++)
  {
    VaComm1->WriteText(S);
    Application->ProcessMessages();
  }
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ComboPortNumChange(TObject *Sender)
{
  VaComm1->PortNum = ComboPortNum->ItemIndex + 1;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ComboBaudrateChange(TObject *Sender)
{
  VaComm1->Baudrate = TVaBaudrate(ComboBaudrate->ItemIndex + 1);
  Memo1->Lines->Add("Baudrate: " + ComboBaudrate->Text);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ComboDatabitsChange(TObject *Sender)
{
  VaComm1->Databits = TVaDatabits(ComboDatabits->ItemIndex);
  Memo1->Lines->Add("Databits: " + ComboDatabits->Text);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ComboStopbitsChange(TObject *Sender)
{
  VaComm1->Stopbits = TVaStopbits(ComboStopbits->ItemIndex);
  Memo1->Lines->Add("StopBits: " + ComboStopbits->Text);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ComboParityChange(TObject *Sender)
{
  VaComm1->Parity = TVaParity(ComboParity->ItemIndex);
  Memo1->Lines->Add("Parity: " + ComboParity->Text);
}
//---------------------------------------------------------------------------

