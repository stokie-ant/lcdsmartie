// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaTerminal.pas' rev: 5.00

#ifndef VaTerminalHPP
#define VaTerminalHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <VaComm.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vaterminal
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TVaTerminalCursorType { crsBlock, crsUnderline, crsNone };
#pragma option pop

struct TVaTerminalChar
{
	char Ch;
	Graphics::TColor FCol;
	Graphics::TColor BCol;
} ;

typedef DynamicArray<TVaTerminalChar >  TVaTerminalLine;

typedef DynamicArray<DynamicArray<TVaTerminalChar > >  TVaTerminalLineArray;

class DELPHICLASS IVaTerminalEmulation;
class DELPHICLASS TVaTerminal;
class DELPHICLASS TVaTerminalBuffer;
class PASCALIMPLEMENTATION TVaTerminalBuffer : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	TVaTerminal* FOwner;
	DynamicArray<DynamicArray<TVaTerminalChar > >  FBuf;
	int FHeight;
	int FWidth;
	int FWinPos;
	bool FModified;
	TVaTerminalLine __fastcall GetLine(int I);
	void __fastcall SetLine(int I, const TVaTerminalLine Value);
	TVaTerminalChar __fastcall GetCh(int X, int Y);
	void __fastcall SetCh(int X, int Y, const TVaTerminalChar &Value);
	Graphics::TColor __fastcall GetBackground(int X, int Y);
	char __fastcall GetCharacter(int X, int Y);
	Graphics::TColor __fastcall GetColor(int X, int Y);
	void __fastcall SetBackground(int X, int Y, const Graphics::TColor Value);
	void __fastcall SetCharacter(int X, int Y, const char Value);
	void __fastcall SetColor(int X, int Y, const Graphics::TColor Value);
	
public:
	__fastcall TVaTerminalBuffer(TVaTerminal* AOwner, int AWidth, int AHeight);
	__fastcall virtual ~TVaTerminalBuffer(void);
	void __fastcall AdjustWidth(int Value);
	void __fastcall AdjustHeight(int Value);
	void __fastcall Assign(const TVaTerminalBuffer* Value);
	void __fastcall ClearBuffer(void);
	void __fastcall ClearScreen(void);
	void __fastcall InsertLineAndScroll(void);
	__property TVaTerminalChar Ch[int X][int Y] = {read=GetCh, write=SetCh};
	__property char Character[int X][int Y] = {read=GetCharacter, write=SetCharacter};
	__property Graphics::TColor Color[int X][int Y] = {read=GetColor, write=SetColor};
	__property Graphics::TColor Background[int X][int Y] = {read=GetBackground, write=SetBackground};
	__property TVaTerminalLine Line[int I] = {read=GetLine, write=SetLine};
	__property bool Modified = {read=FModified, write=FModified, nodefault};
};


class PASCALIMPLEMENTATION TVaTerminal : public Extctrls::TCustomPanel 
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	int FBorderWidth;
	bool FPainted;
	int FBlinkTime;
	int FSavedBlinkTime;
	bool FFromScroll;
	bool FDrawFinOK;
	TVaTerminalBuffer* FBuffer;
	file FFileCapt;
	int FCaretHeight;
	Graphics::TBitmap* FDrawBuffer;
	TVaTerminalBuffer* FOldBuffer;
	int FColumns;
	Vacomm::TVaDispatcher* FDispatcher;
	int FRows;
	bool FCaretShown;
	bool FCaretCreated;
	Vacomm::TVaComm* FComm;
	TVaTerminalCursorType FCursorType;
	bool FLocalEcho;
	Graphics::TFont* FFont;
	int FInternalLeading;
	bool FCapture;
	AnsiString FCaptureFile;
	int FCharWidth;
	int FLineHeight;
	Classes::TComponent* FOwner;
	bool FScrollBack;
	int FScrollBackRows;
	Stdctrls::TScrollBar* FScrollBar;
	int FCaretX;
	int FCaretY;
	bool FWantAllKeys;
	Graphics::TColor FColor;
	Graphics::TColor FOldFontColor;
	bool FInFontChanged;
	int FScrollPos;
	int FTextTop;
	int FTextLeft;
	int FTextWidth;
	int FTextHeight;
	IVaTerminalEmulation* FEmulation;
	bool FCaptureAppend;
	Graphics::TColor FLocalEchoColor;
	void __fastcall ReadjustWidth(void);
	void __fastcall ReadjustHeight(void);
	void __fastcall LineChanged(unsigned Events);
	void __fastcall DataChanged(Vacomm::PVaData Data, int Count);
	void __fastcall DrawScroll(const int nrLines);
	HIDESBASE void __fastcall FontChanged(System::TObject* Sender);
	void __fastcall SetColumns(int Value);
	void __fastcall SetRows(int Value);
	void __fastcall SetComm(const Vacomm::TVaComm* Value);
	void __fastcall SetCursorType(const TVaTerminalCursorType Value);
	void __fastcall SetBlinkTime(const int Value);
	void __fastcall SetWantAllKeys(const bool Value);
	void __fastcall SetLocalEcho(const bool Value);
	void __fastcall SetCapture(const bool Value);
	void __fastcall SetCaptureFile(const AnsiString Value);
	void __fastcall SetScrollBack(const bool Value);
	void __fastcall SetScrollBackRows(int Value);
	void __fastcall SetupFont(void);
	char __fastcall GetCharacter(int X, int Y);
	void __fastcall SetCharacter(int X, int Y, const char Value);
	Graphics::TColor __fastcall GetCharacterBackground(int X, int Y);
	Graphics::TColor __fastcall GetCharacterColor(int X, int Y);
	void __fastcall SetCharacterBackground(int X, int Y, const Graphics::TColor Value);
	void __fastcall SetCharacterColor(int X, int Y, const Graphics::TColor Value);
	void __fastcall SetBufferBackground(int X, int Y, const Graphics::TColor Value);
	void __fastcall SetBufferChar(int X, int Y, const char Value);
	void __fastcall SetBufferColor(int X, int Y, const Graphics::TColor Value);
	HIDESBASE void __fastcall SetFont(const Graphics::TFont* Value);
	HIDESBASE void __fastcall SetColor(const Graphics::TColor Value);
	void __fastcall SetColorForAll(const Graphics::TColor Value);
	void __fastcall SetBackgroundForAll(const Graphics::TColor Value);
	void __fastcall ScrollBarScroll(System::TObject* Sender, Stdctrls::TScrollCode ScrollCode, int &ScrollPos
		);
	void __fastcall SetEmulation(IVaTerminalEmulation* Value);
	void __fastcall PositionCaret(void);
	void __fastcall SetCaretX(const int Value);
	void __fastcall SetCaretY(const int Value);
	void __fastcall SaveAndSetCaretBlinkTime(void);
	void __fastcall RestoreCaretBlinkTime(void);
	
protected:
	virtual void __fastcall Paint(void);
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyPress(char &Key);
	DYNAMIC void __fastcall KeyUp(Word &Key, Classes::TShiftState Shift);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	HIDESBASE MESSAGE void __fastcall WMEraseBkgnd(Messages::TMessage &M);
	MESSAGE void __fastcall WMGetDlgCode(Messages::TWMNoParams &Message);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMSetFocus &Message);
	void __fastcall OnCanResizeEventHandler(System::TObject* Sender, int &NewWidth, int &NewHeight, bool 
		&Resize);
	int __fastcall CalculateWidth(void);
	int __fastcall CalculateHeight(void);
	
public:
	void __fastcall AddText(const AnsiString Text);
	void __fastcall AddControlText(const AnsiString Text, const Graphics::TColor Color, const Graphics::TColor 
		Bkg);
	void __fastcall Clear(void);
	void __fastcall ClearAll(void);
	void __fastcall ClearAllBuffer(void);
	void __fastcall ClearScreenBuffer(void);
	void __fastcall GotoXY(int X, int Y);
	__fastcall virtual TVaTerminal(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaTerminal(void);
	void __fastcall InsertAndScrollF(int nrLines);
	int __fastcall Scroll(int nrLines);
	void __fastcall UpdateDisplay(void);
	int __fastcall WriteBuf(void *Buf, int Count);
	bool __fastcall WriteChar(char Ch);
	bool __fastcall WriteText(const AnsiString s);
	__property Graphics::TColor BufferBackground[int X][int Y] = {read=GetCharacterBackground, write=SetBufferBackground
		};
	__property char BufferChar[int X][int Y] = {read=GetCharacter, write=SetBufferChar};
	__property Graphics::TColor BufferColor[int X][int Y] = {read=GetCharacterColor, write=SetBufferColor
		};
	__property int CaretX = {read=FCaretX, write=SetCaretX, nodefault};
	__property int CaretY = {read=FCaretY, write=SetCaretY, nodefault};
	__property char Character[int X][int Y] = {read=GetCharacter, write=SetCharacter};
	__property Graphics::TColor CharacterBackground[int X][int Y] = {read=GetCharacterBackground, write=
		SetCharacterBackground};
	__property Graphics::TColor CharacterColor[int X][int Y] = {read=GetCharacterColor, write=SetCharacterColor
		};
	
__published:
	__property bool CaptureAppend = {read=FCaptureAppend, write=FCaptureAppend, nodefault};
	__property int BlinkTime = {read=FBlinkTime, write=SetBlinkTime, nodefault};
	__property bool Capture = {read=FCapture, write=SetCapture, nodefault};
	__property AnsiString CaptureFile = {read=FCaptureFile, write=SetCaptureFile};
	__property Graphics::TColor Color = {read=FColor, write=SetColor, nodefault};
	__property int Columns = {read=FColumns, write=SetColumns, default=80};
	__property Vacomm::TVaComm* Comm = {read=FComm, write=SetComm};
	__property TVaTerminalCursorType CursorType = {read=FCursorType, write=SetCursorType, nodefault};
	__property IVaTerminalEmulation* Emulation = {read=FEmulation, write=SetEmulation};
	__property bool LocalEcho = {read=FLocalEcho, write=SetLocalEcho, nodefault};
	__property Graphics::TColor LocalEchoColor = {read=FLocalEchoColor, write=FLocalEchoColor, nodefault
		};
	__property OnClick ;
	__property OnDblClick ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property int Rows = {read=FRows, write=SetRows, default=25};
	__property bool ScrollBack = {read=FScrollBack, write=SetScrollBack, default=0};
	__property int ScrollBackRows = {read=FScrollBackRows, write=SetScrollBackRows, default=250};
	__property ShowHint ;
	__property Graphics::TFont* Font = {read=FFont, write=SetFont};
	__property bool WantAllKeys = {read=FWantAllKeys, write=SetWantAllKeys, nodefault};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TVaTerminal(HWND ParentWindow) : Extctrls::TCustomPanel(
		ParentWindow) { }
	#pragma option pop
	
private:
	void *__IVaCommUser;	/* Vacomm::IVaCommUser */
	
public:
	operator IVaCommUser*(void) { return (IVaCommUser*)&__IVaCommUser; }
	
};


class PASCALIMPLEMENTATION IVaTerminalEmulation : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
protected:
	TVaTerminal* FTerminal;
	virtual void __fastcall DataArrived(Vacomm::PVaData Data, int Count) = 0 ;
	virtual void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift) = 0 ;
	virtual void __fastcall KeyPress(char &Key) = 0 ;
	virtual void __fastcall KeyUp(Word &Key, Classes::TShiftState Shift) = 0 ;
	void __fastcall SetTerminal(const TVaTerminal* Value);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual IVaTerminalEmulation(Classes::TComponent* AOwner)
		 : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~IVaTerminalEmulation(void) { }
	#pragma option pop
	
};


class DELPHICLASS TVaTTYEmulation;
class PASCALIMPLEMENTATION TVaTTYEmulation : public IVaTerminalEmulation 
{
	typedef IVaTerminalEmulation inherited;
	
private:
	char FLastChar;
	
public:
	__fastcall virtual TVaTTYEmulation(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaTTYEmulation(void);
	virtual void __fastcall DataArrived(Vacomm::PVaData Data, int Count);
	virtual void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	virtual void __fastcall KeyPress(char &Key);
	virtual void __fastcall KeyUp(Word &Key, Classes::TShiftState Shift);
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vaterminal */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vaterminal;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaTerminal
