// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaBuffer.pas' rev: 5.00

#ifndef VaBufferHPP
#define VaBufferHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaComm.hpp>	// Pascal unit
#include <VaTypes.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vabuffer
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TVaBuffer;
class PASCALIMPLEMENTATION TVaBuffer : public Vacomm::TVaCommComponent 
{
	typedef Vacomm::TVaCommComponent inherited;
	
private:
	char *FData;
	int FSize;
	int FStartPtr;
	int FEndPtr;
	bool FFull;
	Classes::TNotifyEvent FOnChange;
	Classes::TNotifyEvent FOnOverflow;
	void __fastcall SetSize(int Value);
	
protected:
	virtual void __fastcall Changed(void);
	virtual void __fastcall DataChanged(Vacomm::PVaData Data, int Count);
	void __fastcall IncPtr(int &Ptr, const int Value);
	__property int StartPtr = {read=FStartPtr, nodefault};
	__property int EndPtr = {read=FEndPtr, nodefault};
	
public:
	__fastcall virtual TVaBuffer(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaBuffer(void);
	void __fastcall Clear(void);
	bool __fastcall Peek(void *Buf, int Count);
	HIDESBASE bool __fastcall Remove(int Count);
	bool __fastcall Read(void *Buf, int Count);
	bool __fastcall Write(const void *Buf, int Count);
	int __fastcall BufFree(void);
	int __fastcall BufUsed(void);
	__property bool Full = {read=FFull, nodefault};
	
__published:
	__property int Size = {read=FSize, write=SetSize, default=2048};
	__property Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	__property Classes::TNotifyEvent OnOverflow = {read=FOnOverflow, write=FOnOverflow};
	__property Active ;
};


//-- var, const, procedure ---------------------------------------------------
static const Word DefSize = 0x800;

}	/* namespace Vabuffer */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vabuffer;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaBuffer
