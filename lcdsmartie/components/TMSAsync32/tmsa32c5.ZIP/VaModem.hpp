// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaModem.pas' rev: 5.00

#ifndef VaModemHPP
#define VaModemHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaTriggers.hpp>	// Pascal unit
#include <VaUtils.hpp>	// Pascal unit
#include <VaComm.hpp>	// Pascal unit
#include <VaClasses.hpp>	// Pascal unit
#include <VaTypes.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vamodem
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS EVaModemException;
class PASCALIMPLEMENTATION EVaModemException : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EVaModemException(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EVaModemException(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EVaModemException(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EVaModemException(int Ident, const System::TVarRec * 
		Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EVaModemException(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EVaModemException(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EVaModemException(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EVaModemException(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EVaModemException(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TVaRingDetect { rdLine, rdMsg, rdNone };
#pragma option pop

typedef void __fastcall (__closure *TVaRingEvent)(System::TObject* Sender, int Rings, bool &AcceptCall
	);

typedef void __fastcall (__closure *TVaConnectEvent)(System::TObject* Sender, const AnsiString ConnectString
	);

#pragma option push -b-
enum TVaModemAction { maNone, maInit, maReset, maDial, maAnswer, maHangup };
#pragma option pop

class DELPHICLASS TVaCustomModem;
class PASCALIMPLEMENTATION TVaCustomModem : public Vacomm::TVaCommComponent 
{
	typedef Vacomm::TVaCommComponent inherited;
	
private:
	AnsiString FOK;
	AnsiString FRing;
	AnsiString FBusy;
	AnsiString FVoice;
	AnsiString FNoCarrier;
	AnsiString FNoDialTone;
	AnsiString FError;
	AnsiString FConnect;
	Classes::TStrings* FConfig;
	int FDialTimeout;
	int FAnswerTimeout;
	int FCommandTimeout;
	int FCharDelay;
	AnsiString FConnectString;
	TVaRingDetect FRingDetect;
	int FRingCount;
	Vatriggers::TVaTimer* FRingTimer;
	Vatriggers::TVaTimer* FActionTimer;
	TVaModemAction FModemAction;
	int FDtrDropDelay;
	TVaRingEvent FOnRingDetect;
	Classes::TNotifyEvent FOnRingWaitTimeout;
	Classes::TNotifyEvent FOnOK;
	Classes::TNotifyEvent FOnBusy;
	Classes::TNotifyEvent FOnVoice;
	Classes::TNotifyEvent FOnNoCarrier;
	Classes::TNotifyEvent FOnNoDialTone;
	Classes::TNotifyEvent FOnError;
	TVaConnectEvent FOnConnect;
	Classes::TNotifyEvent FOnAnswerTimeout;
	Classes::TNotifyEvent FOnDialTimeout;
	Classes::TNotifyEvent FOnCommandTimeout;
	int __fastcall GetRingWaitTimeout(void);
	void __fastcall SetRingWaitTimeout(int Value);
	void __fastcall SetConfig(Classes::TStrings* Value);
	void __fastcall ConfigChanged(System::TObject* Sender);
	
protected:
	AnsiString Resp;
	char TermChar;
	void __fastcall ReceiveChar(char Ch);
	virtual void __fastcall HandleRingEvent(void);
	void __fastcall RingWaitTimeoutEvent(System::TObject* Sender);
	void __fastcall ActionWaitTimeoutEvent(System::TObject* Sender);
	void __fastcall CheckWaiting(void);
	void __fastcall CheckResponse(void);
	void __fastcall InitConfig(void);
	AnsiString __fastcall ConfigValue(AnsiString Tag);
	virtual void __fastcall LineChanged(unsigned Events);
	virtual void __fastcall DataChanged(Vacomm::PVaData Data, int Count);
	__property Classes::TStrings* Config = {read=FConfig, write=SetConfig};
	__property int DialTimeout = {read=FDialTimeout, write=FDialTimeout, default=30000};
	__property int AnswerTimeout = {read=FAnswerTimeout, write=FAnswerTimeout, default=30000};
	__property int RingWaitTimeout = {read=GetRingWaitTimeout, write=SetRingWaitTimeout, default=5000};
		
	__property int CommandTimeout = {read=FCommandTimeout, write=FCommandTimeout, default=5000};
	__property int CharDelay = {read=FCharDelay, write=FCharDelay, default=0};
	__property TVaRingDetect RingDetect = {read=FRingDetect, write=FRingDetect, default=0};
	__property int DtrDropDelay = {read=FDtrDropDelay, write=FDtrDropDelay, default=1000};
	__property TVaRingEvent OnRingDetect = {read=FOnRingDetect, write=FOnRingDetect};
	__property Classes::TNotifyEvent OnRingWaitTimeout = {read=FOnRingWaitTimeout, write=FOnRingWaitTimeout
		};
	__property Classes::TNotifyEvent OnOK = {read=FOnOK, write=FOnOK};
	__property Classes::TNotifyEvent OnBusy = {read=FOnBusy, write=FOnBusy};
	__property Classes::TNotifyEvent OnVoice = {read=FOnVoice, write=FOnVoice};
	__property Classes::TNotifyEvent OnNoCarrier = {read=FOnNoCarrier, write=FOnNoCarrier};
	__property Classes::TNotifyEvent OnNoDialTone = {read=FOnNoDialTone, write=FOnNoDialTone};
	__property Classes::TNotifyEvent OnError = {read=FOnError, write=FOnError};
	__property TVaConnectEvent OnConnect = {read=FOnConnect, write=FOnConnect};
	__property Classes::TNotifyEvent OnAnswerTimeout = {read=FOnAnswerTimeout, write=FOnAnswerTimeout};
		
	__property Classes::TNotifyEvent OnDialTimeout = {read=FOnDialTimeout, write=FOnDialTimeout};
	__property Classes::TNotifyEvent OnCommandTimeout = {read=FOnCommandTimeout, write=FOnCommandTimeout
		};
	
public:
	__fastcall virtual TVaCustomModem(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaCustomModem(void);
	void __fastcall Init(void);
	void __fastcall Reset(void);
	void __fastcall Dial(AnsiString PhoneNumber);
	void __fastcall Answer(void);
	void __fastcall Cancel(void);
	void __fastcall Hangup(bool DropDTR);
	void __fastcall PutCommand(AnsiString Cmd);
	void __fastcall WaitForResponse(int Delay);
	__property AnsiString ConnectString = {read=FConnectString};
	__property TVaModemAction ModemAction = {read=FModemAction, nodefault};
};


class DELPHICLASS TVaModem;
class PASCALIMPLEMENTATION TVaModem : public TVaCustomModem 
{
	typedef TVaCustomModem inherited;
	
__published:
	__property Active ;
	__property Config ;
	__property DialTimeout ;
	__property AnswerTimeout ;
	__property RingWaitTimeout ;
	__property CommandTimeout ;
	__property CharDelay ;
	__property RingDetect ;
	__property DtrDropDelay ;
	__property OnRingDetect ;
	__property OnRingWaitTimeout ;
	__property OnOK ;
	__property OnBusy ;
	__property OnVoice ;
	__property OnNoCarrier ;
	__property OnNoDialTone ;
	__property OnError ;
	__property OnConnect ;
	__property OnAnswerTimeout ;
	__property OnDialTimeout ;
	__property OnCommandTimeout ;
public:
	#pragma option push -w-inl
	/* TVaCustomModem.Create */ inline __fastcall virtual TVaModem(Classes::TComponent* AOwner) : TVaCustomModem(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TVaCustomModem.Destroy */ inline __fastcall virtual ~TVaModem(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vamodem */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vamodem;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaModem
