// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaSystem.pas' rev: 6.00

#ifndef VaSystemHPP
#define VaSystemHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaTriggers.hpp>	// Pascal unit
#include <VaComm.hpp>	// Pascal unit
#include <VaClasses.hpp>	// Pascal unit
#include <VaTypes.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vasystem
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TVaWaitMessageEvent)(System::TObject* Sender, int Index);

class DELPHICLASS TVaWaitMessage;
class PASCALIMPLEMENTATION TVaWaitMessage : public Vacomm::TVaCommComponent 
{
	typedef Vacomm::TVaCommComponent inherited;
	
private:
	Classes::TStrings* FStrings;
	Classes::TStrings* FCompareData;
	Classes::TStrings* FReceived;
	bool FCaseSensitive;
	TVaWaitMessageEvent FOnMessage;
	void __fastcall SetStrings(Classes::TStrings* Value);
	void __fastcall StringsChanged(System::TObject* Sender);
	
protected:
	void __fastcall ReceiveChar(char Ch);
	virtual void __fastcall DataChanged(Vacomm::PVaData Data, int Count);
	virtual void __fastcall Loaded(void);
	
public:
	__fastcall virtual TVaWaitMessage(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaWaitMessage(void);
	void __fastcall ResetStrings(void);
	
__published:
	__property Classes::TStrings* Strings = {read=FStrings, write=SetStrings};
	__property bool CaseSensitive = {read=FCaseSensitive, write=FCaseSensitive, default=0};
	__property TVaWaitMessageEvent OnMessage = {read=FOnMessage, write=FOnMessage};
	__property Active ;
};


typedef void __fastcall (__closure *TVaCaptureMsgEvent)(System::TObject* Sender, const AnsiString Data);

class DELPHICLASS TVaCapture;
class PASCALIMPLEMENTATION TVaCapture : public Vacomm::TVaCommComponent 
{
	typedef Vacomm::TVaCommComponent inherited;
	
private:
	AnsiString FDataStart;
	AnsiString FDataFinish;
	int FMaxMsgLen;
	TVaCaptureMsgEvent FOnMessage;
	void __fastcall SetDataStart(const AnsiString Value);
	void __fastcall SetDataFinish(const AnsiString Value);
	void __fastcall HandleMessage(AnsiString Msg);
	
protected:
	AnsiString Buffer;
	AnsiString StartCtrl;
	AnsiString FinishCtrl;
	int StartLen;
	int FinishLen;
	AnsiString Prefix;
	int Level;
	void __fastcall ReceiveChar(char Ch);
	virtual void __fastcall DataChanged(Vacomm::PVaData Data, int Count);
	
public:
	__fastcall virtual TVaCapture(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaCapture(void);
	void __fastcall Reset(void);
	
__published:
	__property AnsiString DataStart = {read=FDataStart, write=SetDataStart};
	__property AnsiString DataFinish = {read=FDataFinish, write=SetDataFinish};
	__property int MaxMsgLen = {read=FMaxMsgLen, write=FMaxMsgLen, default=999};
	__property TVaCaptureMsgEvent OnMessage = {read=FOnMessage, write=FOnMessage};
	__property Active ;
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vasystem */
using namespace Vasystem;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaSystem
